def solve_exo_22():
    L=liste_triee()
    score=0
    for k in range(0,len(L)):
        i=L[k][1:-1]
        score+=add_lettre(i)*(k+1)
    return score

def liste_triee():
    #ouvrir la liste
    f=open('p022_names.txt','r')
    fichier=f.read()
    lol=fichier.split('"')
   # f.replace('"','') #remplace les " par des vides
    f2=sorted(fichier.split(','), key=str.lower)
    return f2

def add_lettre(prenom):
    k=0
    somme=0
    while k<len(prenom):
        somme+=alphabet(prenom[k])
        k+=1
    return somme
        

def alphabet(lettre):
    L=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
    k=0
    while L[k]!=lettre and k<=26:
        k+=1
    return k+1


assert add_lettre("COLIN")*938==49714
print (solve_exo_22())