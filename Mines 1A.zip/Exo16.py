def solve_exo_16(n):
    valeur = n
    somme = 0
    while valeur!=0:
        chiffre = valeur%10
        valeur = valeur//10
        somme += chiffre
    return somme

assert solve_exo_16(2**15)==26
print (solve_exo_16(2**1000))