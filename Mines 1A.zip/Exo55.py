'''
Je cherche les nombres entre 1 et 10000 qui ne forment pas de palyndromes en dessous de 50 it�rations 
'''
def exo_55():
    compteur=0
    for k in range (1,10000):
#        if est_palyndrome(k)==True:
#            compteur_pal+=1
            if lychrel(k)==True:
                compteur+=1
    return compteur

def lychrel(nombre):
    u=nombre
    iteration=0
    pal=True 
    while pal==True and iteration<50:
        u=additionne_palyndrome(u)
        iteration+=1
        if est_palyndrome(u):
            pal=False #ce nombre n'est plus un nombre de lychrel
    return pal

def est_palyndrome(nombre):
    L=str(nombre)
    answer=True
    for k in range(0,int(len(L)/2)):
        if L[k]!=L[-(k+1)]:
            answer=False
    return answer

def additionne_palyndrome(nombre):
    L1=str(nombre)
    L2=''
    for k in range(0,len(L1)):
        L2+=str(L1[-(k+1)])
    return int(L1)+int(L2)
    
assert lychrel(4994)==True
print(exo_55())